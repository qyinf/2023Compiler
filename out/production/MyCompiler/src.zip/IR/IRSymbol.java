package IR;

public interface IRSymbol {
    public int getId();
}
