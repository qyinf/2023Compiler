package Symbols;

public class Symbol {
    private String Ident;

    public String getIdent() {
        return this.Ident;
    }

    public Symbol(String tmp) {
        this.Ident = tmp;
    }
}
