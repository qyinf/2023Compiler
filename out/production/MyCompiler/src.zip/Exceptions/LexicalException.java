package Exceptions;

public class LexicalException extends Exception{

}
