package Exceptions;

public class ASTException extends Exception {
    public void print() {
        System.out.println("不存在该类型");
    }
}
